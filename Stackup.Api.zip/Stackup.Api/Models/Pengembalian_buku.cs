public class Pengembalian_buku
{
    public int Id { get; set; }
    public int nama_peminjam { get; set; }
    public int judul_buku_pinjaman { get; set; }
    public string? waktu_pengembalian { get; set; }
    public int denda { get; set; }
}
