public class Inventori
{
    public int id { get; set; }

    public string? judul_buku {get; set;}
    
    public string? rak_buku {get; set;}
    
    public string? penerbit_buku {get; set;}
    
    public string? pengarang_buku {get; set;}
    
    public int tahun_buku {get; set;}
}