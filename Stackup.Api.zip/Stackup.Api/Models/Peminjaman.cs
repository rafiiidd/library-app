public class Peminjaman
{
    public int id { get; set;}
    public int nama_peminjam { get; set;}
    public int judul_buku_pinjaman { get; set;}
    public string waktu_peminjaman { get; set;}
    public int durasi_peminjaman { get; set;}
}