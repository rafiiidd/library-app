public class Pengguna
{
    public int id { get; set; }

    public string? nama {get; set;}
    public string? alamat {get; set;}
    public string? pass {get; set;}
}